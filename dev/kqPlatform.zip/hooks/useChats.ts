"use client";

import { useEffect, useState } from "react";
import { subscribeToUserChats } from "@/lib/firestore/chats";
import { getUserById } from "@/lib/firestore/users";
import type { ChatDocument, UserProfile } from "@/types";

export interface EnrichedChat extends ChatDocument {
  otherUser: Pick<UserProfile, "userId" | "username"> | null;
}

export function useChats(userId: string) {
  const [chats, setChats] = useState<EnrichedChat[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!userId) return;

    const unsub = subscribeToUserChats(userId, async (rawChats) => {
      const enriched = await Promise.all(
        rawChats.map(async (chat) => {
          const otherId = chat.participants.find((p) => p !== userId) ?? null;
          if (!otherId) return { ...chat, otherUser: null };
          const profile = await getUserById(otherId);
          return {
            ...chat,
            otherUser: profile
              ? { userId: profile.userId, username: profile.username }
              : null,
          };
        })
      );

      enriched.sort(
        (a, b) =>
          (b.lastMessage?.timestamp ?? b.createdAt) -
          (a.lastMessage?.timestamp ?? a.createdAt)
      );

      setChats(enriched);
      setLoading(false);
    });

    return unsub;
  }, [userId]);

  return { chats, loading };
}
