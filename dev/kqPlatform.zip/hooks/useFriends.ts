"use client";

import { useEffect, useState } from "react";
import { doc, onSnapshot } from "firebase/firestore";
import { db } from "@/lib/firebase/client";
import { getUserById } from "@/lib/firestore/users";
import type { UserProfile, SearchedUser } from "@/types";

export interface FriendsData {
  friends: SearchedUser[];
  incoming: SearchedUser[];
  outgoing: SearchedUser[];
}

export function useFriends(userId: string) {
  const [data, setData] = useState<FriendsData>({
    friends: [],
    incoming: [],
    outgoing: [],
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!userId) return;

    const unsub = onSnapshot(doc(db, "users", userId), async (snap) => {
      if (!snap.exists()) return;
      const profile = snap.data() as UserProfile;

      const [friends, incoming, outgoing] = await Promise.all([
        Promise.all(
          profile.friends.map(async (id) => {
            const u = await getUserById(id);
            return u ? { userId: u.userId, username: u.username } : null;
          })
        ),
        Promise.all(
          profile.friendRequests.incoming.map(async (id) => {
            const u = await getUserById(id);
            return u ? { userId: u.userId, username: u.username } : null;
          })
        ),
        Promise.all(
          profile.friendRequests.outgoing.map(async (id) => {
            const u = await getUserById(id);
            return u ? { userId: u.userId, username: u.username } : null;
          })
        ),
      ]);

      setData({
        friends: friends.filter(Boolean) as SearchedUser[],
        incoming: incoming.filter(Boolean) as SearchedUser[],
        outgoing: outgoing.filter(Boolean) as SearchedUser[],
      });
      setLoading(false);
    });

    return unsub;
  }, [userId]);

  return { data, loading };
}
