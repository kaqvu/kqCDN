"use client";

import { useEffect, useState, useCallback, useRef } from "react";
import {
  collection,
  onSnapshot,
  query,
  orderBy,
  limit,
  getDocs,
  endBefore,
  limitToLast,
  QueryDocumentSnapshot,
  DocumentData,
} from "firebase/firestore";
import { db } from "@/lib/firebase/client";
import type { Message } from "@/types";

const PAGE_SIZE = 30;

export function useMessages(chatId: string) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [loading, setLoading] = useState(true);
  const [hasMore, setHasMore] = useState(false);
  const oldestDocRef = useRef<QueryDocumentSnapshot<DocumentData> | null>(null);

  useEffect(() => {
    if (!chatId) return;

    setMessages([]);
    setLoading(true);
    oldestDocRef.current = null;

    const messagesRef = collection(db, "messages", chatId, "messages");
    const q = query(
      messagesRef,
      orderBy("timestamp", "asc"),
      limit(PAGE_SIZE)
    );

    const unsub = onSnapshot(q, (snapshot) => {
      if (snapshot.docs.length > 0) {
        oldestDocRef.current = snapshot.docs[0];
      }
      const msgs: Message[] = snapshot.docs.map((d) => ({
        messageId: d.id,
        ...(d.data() as Omit<Message, "messageId">),
      }));
      setMessages(msgs);
      setHasMore(snapshot.docs.length === PAGE_SIZE);
      setLoading(false);
    });

    return unsub;
  }, [chatId]);

  const loadMore = useCallback(async () => {
    if (!oldestDocRef.current || !chatId) return;

    const messagesRef = collection(db, "messages", chatId, "messages");
    const q = query(
      messagesRef,
      orderBy("timestamp", "asc"),
      endBefore(oldestDocRef.current),
      limitToLast(PAGE_SIZE)
    );

    const snapshot = await getDocs(q);
    if (snapshot.docs.length === 0) {
      setHasMore(false);
      return;
    }

    oldestDocRef.current = snapshot.docs[0];
    const older: Message[] = snapshot.docs.map((d) => ({
      messageId: d.id,
      ...(d.data() as Omit<Message, "messageId">),
    }));

    setMessages((prev) => [...older, ...prev]);
    setHasMore(snapshot.docs.length === PAGE_SIZE);
  }, [chatId]);

  return { messages, loading, hasMore, loadMore };
}
