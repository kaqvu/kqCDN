"use client";

import { useEffect } from "react";
import styles from "./ModalOverlay.module.css";

interface ModalOverlayProps {
  onClose: () => void;
  children: React.ReactNode;
  maxWidth?: number;
}

export function ModalOverlay({ onClose, children, maxWidth = 520 }: ModalOverlayProps) {
  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    document.addEventListener("keydown", handleKey);
    return () => document.removeEventListener("keydown", handleKey);
  }, [onClose]);

  return (
    <div
      className={styles.backdrop}
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
      role="dialog"
      aria-modal="true"
    >
      <div className={styles.modal} style={{ maxWidth }}>
        {children}
      </div>
    </div>
  );
}
