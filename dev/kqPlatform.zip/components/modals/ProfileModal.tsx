"use client";

import { useState, useCallback } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { useRouter } from "next/navigation";
import { ModalOverlay } from "@/components/modals/ModalOverlay";
import { Button } from "@/components/ui/Button";
import { Input } from "@/components/ui/Input";
import { Avatar } from "@/components/ui/Avatar";
import { UserSearch } from "@/components/friends/UserSearch";
import { FriendRequestList } from "@/components/friends/FriendRequestList";
import { useFriends } from "@/hooks/useFriends";
import { updateUsername } from "@/lib/firestore/users";
import { auth } from "@/lib/firebase/client";
import styles from "./ProfileModal.module.css";

type Tab = "profile" | "friends" | "requests" | "danger";

interface ProfileModalProps {
  onClose: () => void;
}

export function ProfileModal({ onClose }: ProfileModalProps) {
  const { user, profile, logout, changePassword, refreshProfile } = useAuth();
  const router = useRouter();
  const { data: friendsData } = useFriends(user?.uid ?? "");

  const [tab, setTab] = useState<Tab>("profile");
  const [username, setUsername] = useState(profile?.username ?? "");
  const [usernameError, setUsernameError] = useState("");
  const [usernameLoading, setUsernameLoading] = useState(false);
  const [usernameSuccess, setUsernameSuccess] = useState(false);

  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [passwordError, setPasswordError] = useState("");
  const [passwordLoading, setPasswordLoading] = useState(false);
  const [passwordSuccess, setPasswordSuccess] = useState(false);

  const [deleteLoading, setDeleteLoading] = useState(false);
  const [deleteConfirm, setDeleteConfirm] = useState("");

  const handleUsernameUpdate = useCallback(async () => {
    if (!profile || !username.trim() || username === profile.username) return;
    setUsernameError("");
    setUsernameSuccess(false);

    if (!/^[a-zA-Z0-9_]{3,20}$/.test(username)) {
      setUsernameError("3–20 chars, letters/numbers/underscores only");
      return;
    }

    setUsernameLoading(true);
    try {
      await updateUsername(user!.uid, profile.username, username.trim());
      await refreshProfile();
      setUsernameSuccess(true);
    } catch (e: unknown) {
      setUsernameError(e instanceof Error ? e.message : "Update failed");
    } finally {
      setUsernameLoading(false);
    }
  }, [profile, username, user, refreshProfile]);

  const handlePasswordChange = useCallback(async () => {
    setPasswordError("");
    setPasswordSuccess(false);
    if (!currentPassword || !newPassword) {
      setPasswordError("Both fields are required");
      return;
    }
    if (newPassword.length < 8) {
      setPasswordError("New password must be at least 8 characters");
      return;
    }
    setPasswordLoading(true);
    try {
      await changePassword(currentPassword, newPassword);
      setPasswordSuccess(true);
      setCurrentPassword("");
      setNewPassword("");
    } catch {
      setPasswordError("Current password is incorrect");
    } finally {
      setPasswordLoading(false);
    }
  }, [currentPassword, newPassword, changePassword]);

  const handleDeleteAccount = useCallback(async () => {
    if (deleteConfirm !== "DELETE") return;
    setDeleteLoading(true);
    try {
      const idToken = await auth.currentUser!.getIdToken();
      const res = await fetch("/api/delete-account", {
        method: "POST",
        headers: { authorization: `Bearer ${idToken}` },
      });
      if (!res.ok) throw new Error("Deletion failed");
      await logout();
      router.replace("/login");
    } catch {
      setDeleteLoading(false);
    }
  }, [deleteConfirm, logout, router]);

  const tabs: { id: Tab; label: string }[] = [
    { id: "profile", label: "Profile" },
    { id: "friends", label: "Friends" },
    { id: "requests", label: `Requests${friendsData.incoming.length > 0 ? ` (${friendsData.incoming.length})` : ""}` },
    { id: "danger", label: "Danger Zone" },
  ];

  return (
    <ModalOverlay onClose={onClose} maxWidth={540}>
      <div className={styles.modal}>
        <div className={styles.header}>
          <div className={styles.avatarSection}>
            <Avatar username={profile?.username ?? "?"} size={52} />
            <div>
              <h2 className={styles.displayName}>{profile?.username}</h2>
              <p className={styles.email}>{user?.email}</p>
            </div>
          </div>
          <button className={styles.closeBtn} onClick={onClose} id="profile-modal-close" aria-label="Close modal">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
              <line x1="18" y1="6" x2="6" y2="18" />
              <line x1="6" y1="6" x2="18" y2="18" />
            </svg>
          </button>
        </div>

        <div className={styles.tabs}>
          {tabs.map((t) => (
            <button
              key={t.id}
              className={[styles.tab, tab === t.id ? styles.activeTab : ""].join(" ")}
              onClick={() => setTab(t.id)}
              id={`profile-tab-${t.id}`}
            >
              {t.label}
            </button>
          ))}
        </div>

        <div className={styles.body}>
          {tab === "profile" && (
            <div className={styles.section}>
              <Input
                id="edit-username"
                label="Username"
                value={username}
                onChange={(e) => { setUsername(e.target.value); setUsernameSuccess(false); }}
                error={usernameError}
                placeholder="your_username"
                maxLength={20}
              />
              {usernameSuccess && <p className={styles.success}>Username updated!</p>}
              <Button
                id="save-username-btn"
                onClick={handleUsernameUpdate}
                loading={usernameLoading}
                disabled={username === profile?.username || !username.trim()}
              >
                Save Username
              </Button>

              <div className={styles.divider} />

              <Input
                id="current-password"
                label="Current Password"
                type="password"
                value={currentPassword}
                onChange={(e) => setCurrentPassword(e.target.value)}
                placeholder="••••••••"
              />
              <Input
                id="new-password"
                label="New Password"
                type="password"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                placeholder="••••••••"
                error={passwordError}
              />
              {passwordSuccess && <p className={styles.success}>Password changed!</p>}
              <Button
                id="change-password-btn"
                variant="outline"
                onClick={handlePasswordChange}
                loading={passwordLoading}
              >
                Change Password
              </Button>

              <div className={styles.divider} />

              <Button id="logout-btn" variant="ghost" onClick={logout} fullWidth>
                Sign Out
              </Button>
            </div>
          )}

          {tab === "friends" && (
            <div className={styles.section}>
              <UserSearch currentUserId={user?.uid ?? ""} />
              <div className={styles.divider} />
              <h3 className={styles.sectionTitle}>Your Friends ({friendsData.friends.length})</h3>
              {friendsData.friends.length === 0 ? (
                <p className={styles.empty}>No friends yet. Search for users above.</p>
              ) : (
                <ul className={styles.friendList}>
                  {friendsData.friends.map((f) => (
                    <li key={f.userId} className={styles.friendItem}>
                      <Avatar username={f.username} size={32} />
                      <span>{f.username}</span>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          )}

          {tab === "requests" && (
            <div className={styles.section}>
              <FriendRequestList currentUserId={user?.uid ?? ""} friendsData={friendsData} />
            </div>
          )}

          {tab === "danger" && (
            <div className={styles.section}>
              <div className={styles.dangerBox}>
                <h3 className={styles.dangerTitle}>Delete Account</h3>
                <p className={styles.dangerDesc}>
                  This permanently deletes your account, all messages, and all friend connections. This cannot be undone.
                </p>
                <Input
                  id="delete-confirm-input"
                  label='Type "DELETE" to confirm'
                  value={deleteConfirm}
                  onChange={(e) => setDeleteConfirm(e.target.value)}
                  placeholder="DELETE"
                />
                <Button
                  id="delete-account-btn"
                  variant="danger"
                  onClick={handleDeleteAccount}
                  loading={deleteLoading}
                  disabled={deleteConfirm !== "DELETE"}
                  fullWidth
                >
                  Delete My Account
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>
    </ModalOverlay>
  );
}
