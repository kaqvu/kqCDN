"use client";

import { useState, useCallback, useRef, useEffect } from "react";
import { Input } from "@/components/ui/Input";
import { Button } from "@/components/ui/Button";
import { Avatar } from "@/components/ui/Avatar";
import { Spinner } from "@/components/ui/Spinner";
import { searchUsersByUsername } from "@/lib/firestore/users";
import { sendFriendRequest } from "@/lib/firestore/friends";
import { debounce } from "@/lib/utils/debounce";
import type { SearchedUser } from "@/types";
import type { QueryDocumentSnapshot, DocumentData } from "firebase/firestore";
import styles from "./UserSearch.module.css";

interface UserSearchProps {
  currentUserId: string;
}

export function UserSearch({ currentUserId }: UserSearchProps) {
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<SearchedUser[]>([]);
  const [searching, setSearching] = useState(false);
  const [hasMore, setHasMore] = useState(false);
  const [sending, setSending] = useState<string | null>(null);
  const [sent, setSent] = useState<Set<string>>(new Set());
  const [error, setError] = useState("");
  const lastDocRef = useRef<QueryDocumentSnapshot<DocumentData> | null>(null);

  const performSearch = useCallback(
    async (q: string, reset: boolean) => {
      if (!q.trim()) {
        setResults([]);
        setHasMore(false);
        return;
      }
      setSearching(true);
      try {
        const { users, lastDoc } = await searchUsersByUsername(
          q.trim(),
          8,
          reset ? undefined : (lastDocRef.current ?? undefined)
        );
        lastDocRef.current = lastDoc;
        const filtered = users.filter((u) => u.userId !== currentUserId);
        setResults(reset ? filtered : (prev) => [...prev, ...filtered]);
        setHasMore(lastDoc !== null);
      } finally {
        setSearching(false);
      }
    },
    [currentUserId]
  );

  const debouncedSearch = useCallback(
    debounce((q: string) => performSearch(q, true), 300),
    [performSearch]
  );

  useEffect(() => {
    lastDocRef.current = null;
    debouncedSearch(query);
  }, [query, debouncedSearch]);

  const handleSendRequest = useCallback(
    async (toUserId: string) => {
      setError("");
      setSending(toUserId);
      try {
        await sendFriendRequest(currentUserId, toUserId);
        setSent((prev) => new Set(prev).add(toUserId));
      } catch (e: unknown) {
        setError(e instanceof Error ? e.message : "Failed to send request");
      } finally {
        setSending(null);
      }
    },
    [currentUserId]
  );

  return (
    <div className={styles.wrapper}>
      <Input
        id="user-search-input"
        placeholder="Search by username…"
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        icon={
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <circle cx="11" cy="11" r="8" />
            <line x1="21" y1="21" x2="16.65" y2="16.65" />
          </svg>
        }
      />
      {error && <p className={styles.error}>{error}</p>}
      {searching && results.length === 0 && (
        <div className={styles.center}>
          <Spinner size={18} />
        </div>
      )}
      {results.length > 0 && (
        <ul className={styles.list}>
          {results.map((u) => (
            <li key={u.userId} className={styles.item}>
              <Avatar username={u.username} size={32} />
              <span className={styles.name}>{u.username}</span>
              {sent.has(u.userId) ? (
                <span className={styles.sent}>Sent</span>
              ) : (
                <Button
                  id={`send-request-${u.userId}`}
                  size="sm"
                  onClick={() => handleSendRequest(u.userId)}
                  loading={sending === u.userId}
                >
                  Add
                </Button>
              )}
            </li>
          ))}
        </ul>
      )}
      {hasMore && (
        <Button
          id="load-more-users"
          variant="ghost"
          size="sm"
          onClick={() => performSearch(query, false)}
          loading={searching}
          fullWidth
        >
          Load more
        </Button>
      )}
      {!searching && query && results.length === 0 && (
        <p className={styles.empty}>No users found</p>
      )}
    </div>
  );
}
