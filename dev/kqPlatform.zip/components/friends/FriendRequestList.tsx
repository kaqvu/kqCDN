"use client";

import { useCallback, useState } from "react";
import { Avatar } from "@/components/ui/Avatar";
import { Button } from "@/components/ui/Button";
import { acceptFriendRequest, declineFriendRequest, cancelFriendRequest } from "@/lib/firestore/friends";
import type { FriendsData } from "@/hooks/useFriends";
import styles from "./FriendRequestList.module.css";

interface FriendRequestListProps {
  currentUserId: string;
  friendsData: FriendsData;
}

export function FriendRequestList({ currentUserId, friendsData }: FriendRequestListProps) {
  const [loadingId, setLoadingId] = useState<string | null>(null);

  const handle = useCallback(
    async (fn: () => Promise<void>, id: string) => {
      setLoadingId(id);
      try {
        await fn();
      } finally {
        setLoadingId(null);
      }
    },
    []
  );

  return (
    <div className={styles.wrapper}>
      <h3 className={styles.sectionTitle}>
        Incoming ({friendsData.incoming.length})
      </h3>
      {friendsData.incoming.length === 0 ? (
        <p className={styles.empty}>No incoming requests</p>
      ) : (
        <ul className={styles.list}>
          {friendsData.incoming.map((u) => (
            <li key={u.userId} className={styles.item}>
              <Avatar username={u.username} size={32} />
              <span className={styles.name}>{u.username}</span>
              <div className={styles.actions}>
                <Button
                  id={`accept-request-${u.userId}`}
                  size="sm"
                  loading={loadingId === `accept-${u.userId}`}
                  onClick={() =>
                    handle(
                      () => acceptFriendRequest(currentUserId, u.userId),
                      `accept-${u.userId}`
                    )
                  }
                >
                  Accept
                </Button>
                <Button
                  id={`decline-request-${u.userId}`}
                  size="sm"
                  variant="ghost"
                  loading={loadingId === `decline-${u.userId}`}
                  onClick={() =>
                    handle(
                      () => declineFriendRequest(currentUserId, u.userId),
                      `decline-${u.userId}`
                    )
                  }
                >
                  Decline
                </Button>
              </div>
            </li>
          ))}
        </ul>
      )}

      <h3 className={styles.sectionTitle}>
        Outgoing ({friendsData.outgoing.length})
      </h3>
      {friendsData.outgoing.length === 0 ? (
        <p className={styles.empty}>No outgoing requests</p>
      ) : (
        <ul className={styles.list}>
          {friendsData.outgoing.map((u) => (
            <li key={u.userId} className={styles.item}>
              <Avatar username={u.username} size={32} />
              <span className={styles.name}>{u.username}</span>
              <Button
                id={`cancel-request-${u.userId}`}
                size="sm"
                variant="ghost"
                loading={loadingId === `cancel-${u.userId}`}
                onClick={() =>
                  handle(
                    () => cancelFriendRequest(currentUserId, u.userId),
                    `cancel-${u.userId}`
                  )
                }
              >
                Cancel
              </Button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
