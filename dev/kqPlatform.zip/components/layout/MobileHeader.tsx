"use client";

import styles from "./MobileHeader.module.css";
import { Avatar } from "@/components/ui/Avatar";
import { useAuth } from "@/contexts/AuthContext";

interface MobileHeaderProps {
  onMenuToggle: () => void;
  title?: string;
}

export function MobileHeader({ onMenuToggle, title }: MobileHeaderProps) {
  const { profile } = useAuth();

  return (
    <header className={styles.header}>
      <button
        className={styles.menuBtn}
        onClick={onMenuToggle}
        id="mobile-menu-toggle"
        aria-label="Toggle menu"
      >
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <line x1="3" y1="6" x2="21" y2="6" />
          <line x1="3" y1="12" x2="21" y2="12" />
          <line x1="3" y1="18" x2="21" y2="18" />
        </svg>
      </button>
      <span className={styles.title}>{title ?? "kqPlatform"}</span>
      <Avatar username={profile?.username ?? "?"} size={30} />
    </header>
  );
}
