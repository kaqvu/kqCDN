"use client";

import styles from "./Avatar.module.css";

interface AvatarProps {
  username: string;
  size?: number;
  onClick?: () => void;
}

export function Avatar({ username, size = 36, onClick }: AvatarProps) {
  const initial = username?.charAt(0)?.toUpperCase() ?? "?";
  const hue = Array.from(username ?? "").reduce(
    (acc, c) => acc + c.charCodeAt(0),
    0
  ) % 360;

  return (
    <span
      className={[styles.avatar, onClick ? styles.clickable : ""].join(" ")}
      style={{
        width: size,
        height: size,
        fontSize: size * 0.4,
        background: `hsl(${hue}, 55%, 38%)`,
      }}
      onClick={onClick}
      role={onClick ? "button" : undefined}
      aria-label={`Avatar for ${username}`}
    >
      {initial}
    </span>
  );
}
