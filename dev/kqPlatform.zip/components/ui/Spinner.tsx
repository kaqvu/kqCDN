"use client";

import styles from "./Spinner.module.css";

interface SpinnerProps {
  size?: number;
  color?: string;
}

export function Spinner({ size = 20, color }: SpinnerProps) {
  return (
    <span
      className={styles.spinner}
      style={{
        width: size,
        height: size,
        borderTopColor: color ?? "var(--accent)",
      }}
      aria-label="Loading"
    />
  );
}
