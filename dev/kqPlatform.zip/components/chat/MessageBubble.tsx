import styles from "./MessageBubble.module.css";
import type { Message } from "@/types";

interface MessageBubbleProps {
  message: Message;
  isSelf: boolean;
  showTime?: boolean;
}

export function MessageBubble({ message, isSelf, showTime }: MessageBubbleProps) {
  return (
    <div className={[styles.wrapper, isSelf ? styles.self : styles.other].join(" ")}>
      <div className={[styles.bubble, isSelf ? styles.selfBubble : styles.otherBubble].join(" ")}>
        <p className={styles.text}>{message.text}</p>
      </div>
      {showTime && (
        <span className={styles.time}>
          {new Date(message.timestamp).toLocaleTimeString([], {
            hour: "2-digit",
            minute: "2-digit",
          })}
        </span>
      )}
    </div>
  );
}
