"use client";

import Link from "next/link";
import { useChats } from "@/hooks/useChats";
import { Avatar } from "@/components/ui/Avatar";
import { Spinner } from "@/components/ui/Spinner";
import styles from "./ChatList.module.css";

interface ChatListProps {
  currentUserId: string;
  activeChatId?: string;
}

export function ChatList({ currentUserId, activeChatId }: ChatListProps) {
  const { chats, loading } = useChats(currentUserId);

  if (loading) {
    return (
      <div className={styles.center}>
        <Spinner />
      </div>
    );
  }

  if (chats.length === 0) {
    return (
      <div className={styles.empty}>
        <p>No chats yet.</p>
        <p className={styles.emptyHint}>Accept a friend request to start chatting.</p>
      </div>
    );
  }

  return (
    <ul className={styles.list}>
      {chats.map((chat) => (
        <li key={chat.chatId}>
          <Link
            href={`/chats/${chat.chatId}`}
            className={[
              styles.item,
              activeChatId === chat.chatId ? styles.active : "",
            ]
              .filter(Boolean)
              .join(" ")}
            id={`chat-item-${chat.chatId}`}
          >
            <Avatar username={chat.otherUser?.username ?? "?"} size={40} />
            <div className={styles.info}>
              <span className={styles.name}>
                {chat.otherUser?.username ?? "Unknown"}
              </span>
              {chat.lastMessage && (
                <span className={styles.preview}>
                  {chat.lastMessage.senderId === currentUserId ? "You: " : ""}
                  {chat.lastMessage.text}
                </span>
              )}
            </div>
            {chat.lastMessage && (
              <span className={styles.time}>
                {formatTime(chat.lastMessage.timestamp)}
              </span>
            )}
          </Link>
        </li>
      ))}
    </ul>
  );
}

function formatTime(ts: number): string {
  const d = new Date(ts);
  const now = new Date();
  const isToday = d.toDateString() === now.toDateString();
  if (isToday) {
    return d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  }
  return d.toLocaleDateString([], { month: "short", day: "numeric" });
}
