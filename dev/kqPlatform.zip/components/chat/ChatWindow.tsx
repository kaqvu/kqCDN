"use client";

import { useEffect, useRef, useCallback } from "react";
import { useMessages } from "@/hooks/useMessages";
import { MessageBubble } from "@/components/chat/MessageBubble";
import { MessageInput } from "@/components/chat/MessageInput";
import { ChatHeader } from "@/components/chat/ChatHeader";
import { Spinner } from "@/components/ui/Spinner";
import { Button } from "@/components/ui/Button";
import type { Message } from "@/types";
import styles from "./ChatWindow.module.css";

interface ChatWindowProps {
  chatId: string;
  currentUserId: string;
  otherUsername: string;
  receiverId: string;
}

export function ChatWindow({
  chatId,
  currentUserId,
  otherUsername,
  receiverId,
}: ChatWindowProps) {
  const { messages, loading, hasMore, loadMore } = useMessages(chatId);
  const bottomRef = useRef<HTMLDivElement>(null);
  const listRef = useRef<HTMLDivElement>(null);
  const prevLengthRef = useRef(0);

  useEffect(() => {
    if (messages.length > prevLengthRef.current) {
      bottomRef.current?.scrollIntoView({ behavior: "smooth" });
    }
    prevLengthRef.current = messages.length;
  }, [messages.length]);

  const shouldShowTime = useCallback(
    (msg: Message, index: number, arr: Message[]) => {
      if (index === arr.length - 1) return true;
      const next = arr[index + 1];
      return next.senderId !== msg.senderId || next.timestamp - msg.timestamp > 60000;
    },
    []
  );

  return (
    <div className={styles.window}>
      <ChatHeader username={otherUsername} />

      <div className={styles.messages} ref={listRef}>
        {loading && (
          <div className={styles.center}>
            <Spinner />
          </div>
        )}
        {!loading && hasMore && (
          <div className={styles.loadMoreWrap}>
            <Button
              id="load-more-messages"
              variant="ghost"
              size="sm"
              onClick={loadMore}
            >
              Load older messages
            </Button>
          </div>
        )}
        <div className={styles.messageList}>
          {messages.map((msg, i) => (
            <MessageBubble
              key={msg.messageId}
              message={msg}
              isSelf={msg.senderId === currentUserId}
              showTime={shouldShowTime(msg, i, messages)}
            />
          ))}
        </div>
        <div ref={bottomRef} />
      </div>

      <MessageInput
        chatId={chatId}
        senderId={currentUserId}
        receiverId={receiverId}
      />
    </div>
  );
}
