import { Avatar } from "@/components/ui/Avatar";
import styles from "./ChatHeader.module.css";

interface ChatHeaderProps {
  username: string;
}

export function ChatHeader({ username }: ChatHeaderProps) {
  return (
    <header className={styles.header}>
      <Avatar username={username} size={34} />
      <div className={styles.info}>
        <span className={styles.name}>{username}</span>
        <span className={styles.status}>Online</span>
      </div>
    </header>
  );
}
