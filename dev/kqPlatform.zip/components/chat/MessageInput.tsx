"use client";

import { useState, useCallback, KeyboardEvent } from "react";
import { sendMessage } from "@/lib/firestore/messages";
import styles from "./MessageInput.module.css";

interface MessageInputProps {
  chatId: string;
  senderId: string;
  receiverId: string;
}

export function MessageInput({ chatId, senderId, receiverId }: MessageInputProps) {
  const [text, setText] = useState("");
  const [sending, setSending] = useState(false);

  const handleSend = useCallback(async () => {
    const trimmed = text.trim();
    if (!trimmed || sending) return;
    setSending(true);
    setText("");
    try {
      await sendMessage(chatId, senderId, receiverId, trimmed);
    } finally {
      setSending(false);
    }
  }, [text, sending, chatId, senderId, receiverId]);

  const handleKeyDown = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <div className={styles.wrapper}>
      <textarea
        id="message-input"
        className={styles.textarea}
        value={text}
        onChange={(e) => setText(e.target.value)}
        onKeyDown={handleKeyDown}
        placeholder="Message…"
        rows={1}
        aria-label="Message input"
        disabled={sending}
      />
      <button
        id="send-message-btn"
        className={[styles.sendBtn, text.trim() ? styles.active : ""].join(" ")}
        onClick={handleSend}
        disabled={!text.trim() || sending}
        aria-label="Send message"
      >
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <line x1="22" y1="2" x2="11" y2="13" />
          <polygon points="22 2 15 22 11 13 2 9 22 2" />
        </svg>
      </button>
    </div>
  );
}
