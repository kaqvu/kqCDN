"use client";

import { useState, useEffect, useCallback } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { useRouter } from "next/navigation";
import { auth } from "@/lib/firebase/client";
import { Button } from "@/components/ui/Button";
import { Spinner } from "@/components/ui/Spinner";
import styles from "../auth.module.css";

export default function VerifyEmailPage() {
  const { user, resendVerification } = useAuth();
  const router = useRouter();
  const [resent, setResent] = useState(false);
  const [resending, setResending] = useState(false);
  const [checking, setChecking] = useState(false);

  useEffect(() => {
    const interval = setInterval(async () => {
      const u = auth.currentUser;
      if (!u) return;
      await u.reload();
      if (u.emailVerified) {
        clearInterval(interval);
        router.replace("/chats");
      }
    }, 4000);
    return () => clearInterval(interval);
  }, [router]);

  const handleResend = useCallback(async () => {
    setResending(true);
    try {
      await resendVerification();
      setResent(true);
    } finally {
      setResending(false);
    }
  }, [resendVerification]);

  const handleCheckNow = useCallback(async () => {
    setChecking(true);
    const u = auth.currentUser;
    if (u) {
      await u.reload();
      if (u.emailVerified) {
        router.replace("/chats");
        return;
      }
    }
    setChecking(false);
  }, [router]);

  return (
    <div className={styles.page}>
      <div className={styles.card}>
        <div className={styles.brand}>kqPlatform</div>
        <div className={styles.verifyIcon}>
          <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="var(--accent)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
            <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z" />
            <polyline points="22,6 12,13 2,6" />
          </svg>
        </div>
        <h1 className={styles.heading}>Check your email</h1>
        <p className={styles.sub}>
          We sent a verification link to{" "}
          <strong className={styles.emailHl}>{user?.email}</strong>.
          Click it to activate your account.
        </p>
        <p className={styles.autoCheck}>
          <Spinner size={12} /> Checking automatically…
        </p>
        <div className={styles.verifyActions}>
          <Button
            id="check-now-btn"
            variant="outline"
            fullWidth
            onClick={handleCheckNow}
            loading={checking}
          >
            I verified — continue
          </Button>
          <Button
            id="resend-verification-btn"
            variant="ghost"
            fullWidth
            onClick={handleResend}
            loading={resending}
            disabled={resent}
          >
            {resent ? "Email resent!" : "Resend verification email"}
          </Button>
        </div>
      </div>
    </div>
  );
}
