"use client";

import { useState, useCallback } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { Input } from "@/components/ui/Input";
import { Button } from "@/components/ui/Button";
import styles from "../auth.module.css";

export default function RegisterPage() {
  const { register } = useAuth();
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleRegister = useCallback(async () => {
    setError("");
    if (!email || !username || !password) {
      setError("Please fill in all fields");
      return;
    }
    if (!/^[a-zA-Z0-9_]{3,20}$/.test(username)) {
      setError("Username: 3–20 chars, letters/numbers/underscores only");
      return;
    }
    if (password.length < 8) {
      setError("Password must be at least 8 characters");
      return;
    }
    setLoading(true);
    try {
      await register(email, username, password);
      router.replace("/verify-email");
    } catch (e: unknown) {
      const code = (e as { code?: string }).code;
      if (code === "auth/email-already-in-use") {
        setError("This email is already registered");
      } else if (code?.includes("username") || (e instanceof Error && e.message === "Username already taken")) {
        setError("Username already taken");
      } else {
        setError("Registration failed. Please try again.");
      }
    } finally {
      setLoading(false);
    }
  }, [email, username, password, register, router]);

  return (
    <div className={styles.page}>
      <div className={styles.card}>
        <div className={styles.brand}>kqPlatform</div>
        <h1 className={styles.heading}>Create account</h1>
        <p className={styles.sub}>Join kqPlatform today</p>

        <form
          className={styles.form}
          onSubmit={(e) => { e.preventDefault(); handleRegister(); }}
          noValidate
        >
          <Input
            id="register-email"
            label="Email"
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="you@example.com"
            autoComplete="email"
          />
          <Input
            id="register-username"
            label="Username"
            type="text"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            placeholder="cool_username"
            maxLength={20}
          />
          <Input
            id="register-password"
            label="Password"
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="••••••••"
            autoComplete="new-password"
            error={error}
          />
          <Button
            id="register-btn"
            type="submit"
            fullWidth
            loading={loading}
          >
            Create Account
          </Button>
        </form>

        <p className={styles.footer}>
          Already have an account?{" "}
          <Link href="/login" id="login-link">Sign In</Link>
        </p>
      </div>
    </div>
  );
}
