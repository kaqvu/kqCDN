"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/contexts/AuthContext";
import { Sidebar } from "@/components/layout/Sidebar";
import { MobileHeader } from "@/components/layout/MobileHeader";
import { Spinner } from "@/components/ui/Spinner";
import styles from "./layout.module.css";

export default function AppLayout({ children }: { children: React.ReactNode }) {
  const { user, loading } = useAuth();
  const router = useRouter();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  useEffect(() => {
    if (loading) return;
    if (!user) {
      router.replace("/login");
    } else if (!user.emailVerified) {
      router.replace("/verify-email");
    }
  }, [user, loading, router]);

  if (loading) {
    return (
      <div className={styles.loadingScreen}>
        <Spinner size={32} />
      </div>
    );
  }

  if (!user || !user.emailVerified) return null;

  return (
    <div className={styles.shell}>
      <div
        className={[styles.sidebarWrap, sidebarOpen ? styles.open : ""].join(" ")}
      >
        <Sidebar />
      </div>
      {sidebarOpen && (
        <div
          className={styles.overlay}
          onClick={() => setSidebarOpen(false)}
        />
      )}
      <div className={styles.content}>
        <MobileHeader
          onMenuToggle={() => setSidebarOpen((v) => !v)}
        />
        <main className={styles.main}>{children}</main>
      </div>
    </div>
  );
}
