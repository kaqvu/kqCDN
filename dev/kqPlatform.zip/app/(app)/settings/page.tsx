"use client";

import { useState, useCallback } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { useRouter } from "next/navigation";
import { Input } from "@/components/ui/Input";
import { Button } from "@/components/ui/Button";
import { Avatar } from "@/components/ui/Avatar";
import { updateUsername } from "@/lib/firestore/users";
import { auth } from "@/lib/firebase/client";
import styles from "./page.module.css";

export default function SettingsPage() {
  const { user, profile, logout, changePassword, refreshProfile } = useAuth();
  const router = useRouter();

  const [username, setUsername] = useState(profile?.username ?? "");
  const [usernameError, setUsernameError] = useState("");
  const [usernameSuccess, setUsernameSuccess] = useState(false);
  const [usernameLoading, setUsernameLoading] = useState(false);

  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [passwordError, setPasswordError] = useState("");
  const [passwordSuccess, setPasswordSuccess] = useState(false);
  const [passwordLoading, setPasswordLoading] = useState(false);

  const [deleteConfirm, setDeleteConfirm] = useState("");
  const [deleteLoading, setDeleteLoading] = useState(false);

  const handleUsernameUpdate = useCallback(async () => {
    if (!profile || !username.trim() || username === profile.username) return;
    setUsernameError("");
    setUsernameSuccess(false);
    if (!/^[a-zA-Z0-9_]{3,20}$/.test(username)) {
      setUsernameError("3–20 chars, letters/numbers/underscores only");
      return;
    }
    setUsernameLoading(true);
    try {
      await updateUsername(user!.uid, profile.username, username.trim());
      await refreshProfile();
      setUsernameSuccess(true);
    } catch (e: unknown) {
      setUsernameError(e instanceof Error ? e.message : "Update failed");
    } finally {
      setUsernameLoading(false);
    }
  }, [profile, username, user, refreshProfile]);

  const handlePasswordChange = useCallback(async () => {
    setPasswordError("");
    setPasswordSuccess(false);
    if (!currentPassword || !newPassword) {
      setPasswordError("Both fields are required");
      return;
    }
    if (newPassword.length < 8) {
      setPasswordError("New password must be at least 8 characters");
      return;
    }
    setPasswordLoading(true);
    try {
      await changePassword(currentPassword, newPassword);
      setPasswordSuccess(true);
      setCurrentPassword("");
      setNewPassword("");
    } catch {
      setPasswordError("Current password is incorrect");
    } finally {
      setPasswordLoading(false);
    }
  }, [currentPassword, newPassword, changePassword]);

  const handleDeleteAccount = useCallback(async () => {
    if (deleteConfirm !== "DELETE") return;
    setDeleteLoading(true);
    try {
      const idToken = await auth.currentUser!.getIdToken();
      const res = await fetch("/api/delete-account", {
        method: "POST",
        headers: { authorization: `Bearer ${idToken}` },
      });
      if (!res.ok) throw new Error("Failed");
      await logout();
      router.replace("/login");
    } catch {
      setDeleteLoading(false);
    }
  }, [deleteConfirm, logout, router]);

  return (
    <div className={styles.page}>
      <div className={styles.header}>
        <h1 className={styles.title}>Settings</h1>
      </div>

      <div className={styles.body}>
        <section className={styles.section}>
          <div className={styles.profileRow}>
            <Avatar username={profile?.username ?? "?"} size={60} />
            <div>
              <p className={styles.profileName}>{profile?.username}</p>
              <p className={styles.profileEmail}>{user?.email}</p>
            </div>
          </div>
        </section>

        <section className={styles.section}>
          <h2 className={styles.sectionTitle}>Account</h2>
          <div className={styles.field}>
            <label className={styles.label}>Email</label>
            <div className={styles.readOnly}>{user?.email}</div>
          </div>
          <div className={styles.field}>
            <Input
              id="settings-username"
              label="Username"
              value={username}
              onChange={(e) => { setUsername(e.target.value); setUsernameSuccess(false); }}
              error={usernameError}
              placeholder="your_username"
              maxLength={20}
            />
            {usernameSuccess && <p className={styles.success}>Username updated!</p>}
            <Button
              id="settings-save-username"
              size="sm"
              onClick={handleUsernameUpdate}
              loading={usernameLoading}
              disabled={username === profile?.username || !username.trim()}
            >
              Save
            </Button>
          </div>
        </section>

        <section className={styles.section}>
          <h2 className={styles.sectionTitle}>Change Password</h2>
          <Input
            id="settings-current-password"
            label="Current Password"
            type="password"
            value={currentPassword}
            onChange={(e) => setCurrentPassword(e.target.value)}
            placeholder="••••••••"
          />
          <Input
            id="settings-new-password"
            label="New Password"
            type="password"
            value={newPassword}
            onChange={(e) => setNewPassword(e.target.value)}
            placeholder="••••••••"
            error={passwordError}
          />
          {passwordSuccess && <p className={styles.success}>Password changed!</p>}
          <Button
            id="settings-change-password"
            variant="outline"
            onClick={handlePasswordChange}
            loading={passwordLoading}
          >
            Update Password
          </Button>
        </section>

        <section className={styles.section}>
          <Button
            id="settings-logout"
            variant="ghost"
            onClick={logout}
          >
            Sign Out
          </Button>
        </section>

        <section className={[styles.section, styles.dangerSection].join(" ")}>
          <h2 className={styles.dangerTitle}>Danger Zone</h2>
          <p className={styles.dangerDesc}>
            Permanently delete your account and all associated data. This cannot be undone.
          </p>
          <Input
            id="settings-delete-confirm"
            label='Type "DELETE" to confirm'
            value={deleteConfirm}
            onChange={(e) => setDeleteConfirm(e.target.value)}
            placeholder="DELETE"
          />
          <Button
            id="settings-delete-account"
            variant="danger"
            onClick={handleDeleteAccount}
            loading={deleteLoading}
            disabled={deleteConfirm !== "DELETE"}
          >
            Delete Account
          </Button>
        </section>
      </div>
    </div>
  );
}
