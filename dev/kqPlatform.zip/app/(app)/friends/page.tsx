"use client";

import { useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { useFriends } from "@/hooks/useFriends";
import { useChats } from "@/hooks/useChats";
import { Avatar } from "@/components/ui/Avatar";
import { FriendRequestList } from "@/components/friends/FriendRequestList";
import { UserSearch } from "@/components/friends/UserSearch";
import Link from "next/link";
import styles from "./page.module.css";

type FriendsTab = "friends" | "requests" | "search";

export default function FriendsPage() {
  const { user } = useAuth();
  const { data: friendsData, loading } = useFriends(user?.uid ?? "");
  const { chats } = useChats(user?.uid ?? "");
  const [tab, setTab] = useState<FriendsTab>("friends");

  const tabs: { id: FriendsTab; label: string }[] = [
    { id: "friends", label: "Friends" },
    {
      id: "requests",
      label: `Requests${friendsData.incoming.length > 0 ? ` (${friendsData.incoming.length})` : ""}`,
    },
    { id: "search", label: "Find Friends" },
  ];

  const getChatId = (friendId: string): string | undefined =>
    chats.find((c) => c.participants.includes(friendId))?.chatId;

  return (
    <div className={styles.page}>
      <div className={styles.header}>
        <h1 className={styles.title}>Friends</h1>
      </div>

      <div className={styles.tabs}>
        {tabs.map((t) => (
          <button
            key={t.id}
            className={[styles.tab, tab === t.id ? styles.active : ""].join(" ")}
            onClick={() => setTab(t.id)}
            id={`friends-tab-${t.id}`}
          >
            {t.label}
          </button>
        ))}
      </div>

      <div className={styles.content}>
        {tab === "friends" && (
          <>
            {loading ? (
              <p className={styles.loading}>Loading…</p>
            ) : friendsData.friends.length === 0 ? (
              <div className={styles.empty}>
                <p>You have no friends yet.</p>
                <p className={styles.emptyHint}>Use &quot;Find Friends&quot; to add people.</p>
              </div>
            ) : (
              <ul className={styles.list}>
                {friendsData.friends.map((f) => {
                  const chatId = getChatId(f.userId);
                  return (
                    <li key={f.userId} className={styles.item}>
                      <Avatar username={f.username} size={42} />
                      <div className={styles.info}>
                        <span className={styles.name}>{f.username}</span>
                      </div>
                      {chatId && (
                        <Link
                          href={`/chats/${chatId}`}
                          className={styles.messageBtn}
                          id={`message-friend-${f.userId}`}
                        >
                          Message
                        </Link>
                      )}
                    </li>
                  );
                })}
              </ul>
            )}
          </>
        )}

        {tab === "requests" && (
          <FriendRequestList
            currentUserId={user?.uid ?? ""}
            friendsData={friendsData}
          />
        )}

        {tab === "search" && (
          <UserSearch currentUserId={user?.uid ?? ""} />
        )}
      </div>
    </div>
  );
}
