"use client";

import { use, useEffect, useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { useRouter } from "next/navigation";
import { getDoc, doc } from "firebase/firestore";
import { db } from "@/lib/firebase/client";
import { getUserById } from "@/lib/firestore/users";
import { ChatWindow } from "@/components/chat/ChatWindow";
import { ChatList } from "@/components/chat/ChatList";
import { Spinner } from "@/components/ui/Spinner";
import type { ChatDocument } from "@/types";
import styles from "./page.module.css";

interface Props {
  params: Promise<{ chatId: string }>;
}

export default function ChatPage({ params }: Props) {
  const { chatId } = use(params);
  const { user } = useAuth();
  const router = useRouter();
  const [chatData, setChatData] = useState<{
    otherUsername: string;
    receiverId: string;
  } | null>(null);
  const [loading, setLoading] = useState(true);
  const [notFound, setNotFound] = useState(false);

  useEffect(() => {
    if (!user || !chatId) return;

    async function load() {
      const chatSnap = await getDoc(doc(db, "chats", chatId));
      if (!chatSnap.exists()) {
        setNotFound(true);
        setLoading(false);
        return;
      }
      const chat = chatSnap.data() as ChatDocument;
      if (!chat.participants.includes(user!.uid)) {
        router.replace("/chats");
        return;
      }
      const otherId = chat.participants.find((p) => p !== user!.uid)!;
      const otherProfile = await getUserById(otherId);
      setChatData({
        otherUsername: otherProfile?.username ?? "Unknown",
        receiverId: otherId,
      });
      setLoading(false);
    }

    load();
  }, [chatId, user, router]);

  if (loading) {
    return (
      <div className={styles.layout}>
        <div className={styles.chatListPanel}>
          <div className={styles.panelHeader}>
            <h2 className={styles.panelTitle}>Messages</h2>
          </div>
          <ChatList currentUserId={user?.uid ?? ""} activeChatId={chatId} />
        </div>
        <div className={styles.center}>
          <Spinner size={28} />
        </div>
      </div>
    );
  }

  if (notFound) {
    return (
      <div className={styles.layout}>
        <div className={styles.chatListPanel}>
          <div className={styles.panelHeader}>
            <h2 className={styles.panelTitle}>Messages</h2>
          </div>
          <ChatList currentUserId={user?.uid ?? ""} activeChatId={chatId} />
        </div>
        <div className={styles.center}>
          <p className={styles.notFound}>Chat not found</p>
        </div>
      </div>
    );
  }

  return (
    <div className={styles.layout}>
      <div className={styles.chatListPanel}>
        <div className={styles.panelHeader}>
          <h2 className={styles.panelTitle}>Messages</h2>
        </div>
        <ChatList currentUserId={user?.uid ?? ""} activeChatId={chatId} />
      </div>
      <div className={styles.chatPanel}>
        <ChatWindow
          chatId={chatId}
          currentUserId={user!.uid}
          otherUsername={chatData!.otherUsername}
          receiverId={chatData!.receiverId}
        />
      </div>
    </div>
  );
}
