"use client";

import { useAuth } from "@/contexts/AuthContext";
import { ChatList } from "@/components/chat/ChatList";
import styles from "./page.module.css";

export default function ChatsPage() {
  const { user } = useAuth();

  return (
    <div className={styles.layout}>
      <aside className={styles.chatListPanel}>
        <div className={styles.panelHeader}>
          <h2 className={styles.panelTitle}>Messages</h2>
        </div>
        <ChatList currentUserId={user?.uid ?? ""} />
      </aside>
      <div className={styles.emptyState}>
        <div className={styles.emptyIcon}>
          <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="var(--border-default)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
            <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
          </svg>
        </div>
        <p className={styles.emptyText}>Select a conversation</p>
        <p className={styles.emptyHint}>Choose from your chats on the left</p>
      </div>
    </div>
  );
}
