import { NextRequest, NextResponse } from "next/server";
import { getAdminAuth, getAdminDb } from "@/lib/firebase/admin";

export const dynamic = "force-dynamic";

export async function POST(req: NextRequest) {
  const authHeader = req.headers.get("authorization");
  if (!authHeader?.startsWith("Bearer ")) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const idToken = authHeader.slice(7);
  let userId: string;

  try {
    const decoded = await getAdminAuth().verifyIdToken(idToken);
    userId = decoded.uid;
  } catch {
    return NextResponse.json({ error: "Invalid token" }, { status: 401 });
  }

  try {
    const adminDb = getAdminDb();
    const adminAuth = getAdminAuth();

    const userRef = adminDb.collection("users").doc(userId);
    const usernameSnap = await userRef.get();

    if (usernameSnap.exists) {
      const { username } = usernameSnap.data() as { username: string };
      await adminDb.collection("usernames").doc(username).delete();
    }

    await userRef.delete();
    await adminAuth.deleteUser(userId);

    const chatsSnap = await adminDb
      .collection("chats")
      .where("participants", "array-contains", userId)
      .get();

    const deletionBatch = adminDb.batch();

    for (const chatDoc of chatsSnap.docs) {
      const chatId = chatDoc.id;

      const messagesSnap = await adminDb
        .collection("messages")
        .doc(chatId)
        .collection("messages")
        .get();

      for (const msgDoc of messagesSnap.docs) {
        deletionBatch.delete(msgDoc.ref);
      }

      deletionBatch.delete(chatDoc.ref);
    }

    await deletionBatch.commit();

    const allUsersSnap = await adminDb
      .collection("users")
      .where("friends", "array-contains", userId)
      .get();

    const friendBatch = adminDb.batch();

    for (const u of allUsersSnap.docs) {
      const data = u.data();
      const friends = (data.friends as string[]).filter((id) => id !== userId);
      const incomingReqs = (data.friendRequests?.incoming as string[]).filter(
        (id) => id !== userId
      );
      const outgoingReqs = (data.friendRequests?.outgoing as string[]).filter(
        (id) => id !== userId
      );
      friendBatch.update(u.ref, {
        friends,
        "friendRequests.incoming": incomingReqs,
        "friendRequests.outgoing": outgoingReqs,
      });
    }

    const incomingReqSnap = await adminDb
      .collection("users")
      .where("friendRequests.outgoing", "array-contains", userId)
      .get();

    for (const u of incomingReqSnap.docs) {
      if (!allUsersSnap.docs.find((d) => d.id === u.id)) {
        const data = u.data();
        const outgoingReqs = (
          data.friendRequests?.outgoing as string[]
        ).filter((id) => id !== userId);
        const incomingReqs = (
          data.friendRequests?.incoming as string[]
        ).filter((id) => id !== userId);
        friendBatch.update(u.ref, {
          "friendRequests.outgoing": outgoingReqs,
          "friendRequests.incoming": incomingReqs,
        });
      }
    }

    await friendBatch.commit();

    return NextResponse.json({ success: true }, { status: 200 });
  } catch (err) {
    console.error("Account deletion error:", err);
    return NextResponse.json({ error: "Deletion failed" }, { status: 500 });
  }
}
