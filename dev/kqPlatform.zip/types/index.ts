export interface UserProfile {
  userId: string;
  email: string;
  username: string;
  friends: string[];
  friendRequests: {
    incoming: string[];
    outgoing: string[];
  };
  createdAt: number;
}

export interface ChatDocument {
  chatId: string;
  participants: string[];
  createdAt: number;
  lastMessage?: {
    text: string;
    senderId: string;
    timestamp: number;
  };
}

export interface Message {
  messageId: string;
  senderId: string;
  receiverId: string;
  text: string;
  timestamp: number;
}

export interface SearchedUser {
  userId: string;
  username: string;
}
