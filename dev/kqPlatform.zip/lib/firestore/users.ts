import {
  doc,
  getDoc,
  setDoc,
  updateDoc,
  collection,
  query,
  where,
  orderBy,
  limit,
  startAfter,
  getDocs,
  serverTimestamp,
  DocumentSnapshot,
  QueryDocumentSnapshot,
} from "firebase/firestore";
import { db } from "@/lib/firebase/client";
import type { UserProfile, SearchedUser } from "@/types";

export async function createUser(
  userId: string,
  email: string,
  username: string
): Promise<void> {
  const userRef = doc(db, "users", userId);
  const usernameRef = doc(db, "usernames", username);

  await setDoc(userRef, {
    userId,
    email,
    username,
    friends: [],
    friendRequests: { incoming: [], outgoing: [] },
    createdAt: Date.now(),
  });

  await setDoc(usernameRef, { userId });
}

export async function getUserById(userId: string): Promise<UserProfile | null> {
  const snap = await getDoc(doc(db, "users", userId));
  if (!snap.exists()) return null;
  return snap.data() as UserProfile;
}

export async function getUserByUsername(
  username: string
): Promise<SearchedUser | null> {
  const usernameSnap = await getDoc(doc(db, "usernames", username));
  if (!usernameSnap.exists()) return null;
  const { userId } = usernameSnap.data() as { userId: string };
  const userSnap = await getDoc(doc(db, "users", userId));
  if (!userSnap.exists()) return null;
  const data = userSnap.data() as UserProfile;
  return { userId: data.userId, username: data.username };
}

export async function searchUsersByUsername(
  searchQuery: string,
  pageLimit: number,
  lastDoc?: QueryDocumentSnapshot
): Promise<{ users: SearchedUser[]; lastDoc: QueryDocumentSnapshot | null }> {
  const usernamesRef = collection(db, "usernames");
  let q = query(
    usernamesRef,
    where("__name__", ">=", searchQuery),
    where("__name__", "<=", searchQuery + "\uf8ff"),
    orderBy("__name__"),
    limit(pageLimit)
  );

  if (lastDoc) {
    q = query(
      usernamesRef,
      where("__name__", ">=", searchQuery),
      where("__name__", "<=", searchQuery + "\uf8ff"),
      orderBy("__name__"),
      startAfter(lastDoc),
      limit(pageLimit)
    );
  }

  const snapshot = await getDocs(q);
  const users: SearchedUser[] = snapshot.docs.map((d) => ({
    userId: (d.data() as { userId: string }).userId,
    username: d.id,
  }));

  const last =
    snapshot.docs.length === pageLimit
      ? snapshot.docs[snapshot.docs.length - 1]
      : null;

  return { users, lastDoc: last };
}

export async function updateUsername(
  userId: string,
  oldUsername: string,
  newUsername: string
): Promise<void> {
  const newUsernameRef = doc(db, "usernames", newUsername);
  const existing = await getDoc(newUsernameRef);
  if (existing.exists()) {
    throw new Error("Username already taken");
  }

  const oldUsernameRef = doc(db, "usernames", oldUsername);
  await setDoc(newUsernameRef, { userId });
  await updateDoc(doc(db, "users", userId), { username: newUsername });

  const oldSnap = await getDoc(oldUsernameRef);
  if (oldSnap.exists()) {
    const { deleteDoc } = await import("firebase/firestore");
    await deleteDoc(oldUsernameRef);
  }
}
