import {
  doc,
  getDoc,
  setDoc,
  collection,
  query,
  where,
  onSnapshot,
  Unsubscribe,
} from "firebase/firestore";
import { db } from "@/lib/firebase/client";
import { generateChatId } from "@/lib/utils/chatId";
import type { ChatDocument } from "@/types";

export async function getOrCreateChat(
  uid1: string,
  uid2: string
): Promise<string> {
  const chatId = generateChatId(uid1, uid2);
  const chatRef = doc(db, "chats", chatId);
  const existing = await getDoc(chatRef);

  if (!existing.exists()) {
    await setDoc(chatRef, {
      chatId,
      participants: [uid1, uid2],
      createdAt: Date.now(),
    });
  }

  return chatId;
}

export function subscribeToUserChats(
  userId: string,
  onChats: (chats: ChatDocument[]) => void
): Unsubscribe {
  const chatsRef = collection(db, "chats");
  const q = query(chatsRef, where("participants", "array-contains", userId));

  return onSnapshot(q, (snapshot) => {
    const chats = snapshot.docs.map((d) => d.data() as ChatDocument);
    onChats(chats);
  });
}
