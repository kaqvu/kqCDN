import {
  doc,
  updateDoc,
  arrayUnion,
  arrayRemove,
  getDoc,
} from "firebase/firestore";
import { db } from "@/lib/firebase/client";
import { getOrCreateChat } from "@/lib/firestore/chats";
import type { UserProfile } from "@/types";

export async function sendFriendRequest(
  fromId: string,
  toId: string
): Promise<void> {
  if (fromId === toId) throw new Error("Cannot send request to yourself");

  const fromRef = doc(db, "users", fromId);
  const toRef = doc(db, "users", toId);

  const [fromSnap, toSnap] = await Promise.all([
    getDoc(fromRef),
    getDoc(toRef),
  ]);

  if (!fromSnap.exists() || !toSnap.exists()) {
    throw new Error("User not found");
  }

  const fromData = fromSnap.data() as UserProfile;
  const toData = toSnap.data() as UserProfile;

  if (fromData.friends.includes(toId)) {
    throw new Error("Already friends");
  }
  if (fromData.friendRequests.outgoing.includes(toId)) {
    throw new Error("Friend request already sent");
  }
  if (toData.friendRequests.outgoing.includes(fromId)) {
    throw new Error("This user already sent you a request");
  }

  await Promise.all([
    updateDoc(fromRef, {
      "friendRequests.outgoing": arrayUnion(toId),
    }),
    updateDoc(toRef, {
      "friendRequests.incoming": arrayUnion(fromId),
    }),
  ]);
}

export async function acceptFriendRequest(
  acceptorId: string,
  requesterId: string
): Promise<void> {
  const acceptorRef = doc(db, "users", acceptorId);
  const requesterRef = doc(db, "users", requesterId);

  await Promise.all([
    updateDoc(acceptorRef, {
      friends: arrayUnion(requesterId),
      "friendRequests.incoming": arrayRemove(requesterId),
    }),
    updateDoc(requesterRef, {
      friends: arrayUnion(acceptorId),
      "friendRequests.outgoing": arrayRemove(acceptorId),
    }),
  ]);

  await getOrCreateChat(acceptorId, requesterId);
}

export async function declineFriendRequest(
  declinerId: string,
  requesterId: string
): Promise<void> {
  const declinerRef = doc(db, "users", declinerId);
  const requesterRef = doc(db, "users", requesterId);

  await Promise.all([
    updateDoc(declinerRef, {
      "friendRequests.incoming": arrayRemove(requesterId),
    }),
    updateDoc(requesterRef, {
      "friendRequests.outgoing": arrayRemove(declinerId),
    }),
  ]);
}

export async function cancelFriendRequest(
  cancelerId: string,
  targetId: string
): Promise<void> {
  const cancelerRef = doc(db, "users", cancelerId);
  const targetRef = doc(db, "users", targetId);

  await Promise.all([
    updateDoc(cancelerRef, {
      "friendRequests.outgoing": arrayRemove(targetId),
    }),
    updateDoc(targetRef, {
      "friendRequests.incoming": arrayRemove(cancelerId),
    }),
  ]);
}
