import {
  collection,
  addDoc,
  query,
  orderBy,
  limit,
  startAfter,
  onSnapshot,
  getDocs,
  Unsubscribe,
  QueryDocumentSnapshot,
  DocumentData,
  updateDoc,
  doc,
} from "firebase/firestore";
import { db } from "@/lib/firebase/client";
import type { Message } from "@/types";

const PAGE_SIZE = 30;

export function subscribeToMessages(
  chatId: string,
  onMessages: (messages: Message[]) => void
): Unsubscribe {
  const messagesRef = collection(db, "messages", chatId, "messages");
  const q = query(messagesRef, orderBy("timestamp", "asc"), limit(PAGE_SIZE));

  return onSnapshot(q, (snapshot) => {
    const messages = snapshot.docs.map((d) => ({
      messageId: d.id,
      ...(d.data() as Omit<Message, "messageId">),
    }));
    onMessages(messages);
  });
}

export async function loadMoreMessages(
  chatId: string,
  beforeDoc: QueryDocumentSnapshot<DocumentData>
): Promise<{
  messages: Message[];
  firstDoc: QueryDocumentSnapshot<DocumentData> | null;
}> {
  const messagesRef = collection(db, "messages", chatId, "messages");
  const q = query(
    messagesRef,
    orderBy("timestamp", "asc"),
    limit(PAGE_SIZE),
    startAfter(beforeDoc)
  );

  const snapshot = await getDocs(q);
  const messages = snapshot.docs.map((d) => ({
    messageId: d.id,
    ...(d.data() as Omit<Message, "messageId">),
  }));

  return {
    messages,
    firstDoc: snapshot.docs.length > 0 ? snapshot.docs[0] : null,
  };
}

export async function sendMessage(
  chatId: string,
  senderId: string,
  receiverId: string,
  text: string
): Promise<void> {
  const messagesRef = collection(db, "messages", chatId, "messages");
  const timestamp = Date.now();

  await addDoc(messagesRef, {
    senderId,
    receiverId,
    text: text.trim(),
    timestamp,
  });

  await updateDoc(doc(db, "chats", chatId), {
    lastMessage: {
      text: text.trim(),
      senderId,
      timestamp,
    },
  });
}
